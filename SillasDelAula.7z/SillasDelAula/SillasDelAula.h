/*#include <stdio.h>
#include <stdlib.h>
#include "SillasDelAula.h"
#define MAX 5

void arrayDeSillas[MAX]
{
    for (i = 0; i < MAX; i++)
    {
        printf("\nColoque el numero de la silla\n");
        scanf("%d", &sillas[i]);
    }
}

void MostrarMaximo(int respuesta1)
{
    printf("El maximo %d", respuesta1);
}

int dameElMaximo(int x[i])
{
    int maximo;
    int paso = 0;
    if(x[i] > maximo && paso == 0)
    {
        maximo = x[i];

        paso++;
    }
    return maximo;
}

void MostrarMinimo(int respuesta2)
{
    printf("El maximo %d", respuesta1);
}

int dameElMinimo(int x[i])
{
    int minimo;
    int paso = 0;
    if(sillas[i] < minimo && paso == 0)
    {
        minimo = silllas[i];

        paso++;
    }
    return minimo;
}
*/
