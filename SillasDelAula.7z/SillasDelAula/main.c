#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"
#define MAX 5//harcodeo

int main()
{
    int sillas[MAX];
    int edades[MAX];
    int legajo;
    int i;
    int aux;
    int maximo;
    int maximoEdad;
    int minimo;
    int minimoEdadLegajo;

    arrayDeSillas(sillas[MAX]);
    MostrarEdadLegajoMaximo(maximoEdad, maximoEdadLegajo);
    /*
    cargar(arraysSilla, cantidad)
    mostrarMasViejos(arraySilla, arraysEdades, cantidad)
    */
    maximo = dameElMaximo(sillas[MAX]);
    printf("%d", maximo);
    minimo = dameElMinimo(sillas[MAX]);
    printf("%d", minimo);

    return 0;
}
/*

Sillas libre, primer silla libre, cantidad
Sillas ocupadas, cantidad
Pedir legajo, por cadad legajo una EDAD(array), ordenar edad

ver arrays en paralelo

los que estan sentador = -1 (mostrar SENTADOS)

ver swap

minimo/maximo de un vector
ordenamiento de un vector

no se pudo ocupar silla, uso de flag no se pudo es 1, se pudo -1

vector, caNTIDAD, ocupar silla, lagajo

harcodeo = legajo 55 11 33 22 44
edades 18 19 81 91 98

*/
