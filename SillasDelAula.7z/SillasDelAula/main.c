#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"
#define MAX 5//harcodeo

int main()
{
    int sillas[MAX];
    int i;
    int aux;
    int maximo;
    int minimo;

    arrayDeSillas(sillas[MAX]);

    maximo = dameElMaximo(sillas[MAX]);
    printf("%d", maximo);
    minimo = dameElMinimo(sillas[MAX]);
    printf("%d", minimo);

    return 0;
}
/*

Sillas libre, primer silla libre, cantidad
Sillas ocupadas, cantidad

minimo/maximo de un vector
ordenamiento de un vector

no se pudo ocupar silla, uso de flag no se pudo es 1, se pudo -1

vector, caNTIDAD, ocupar silla, lagajo

*/
