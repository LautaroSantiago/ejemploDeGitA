#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"
#define MAX 5

void arrayDeSillas(int x[])
{

    int i;

    for (i = 0; i < 5; i++)
    {
        printf("\nColoque el numero de la silla\n");
        scanf("%d", &x[i]);
    }
}
void arraysLagejos(int y[])
{
    int i;

    for (i = 0; i < 5; i++)
    {
        printf("\nColoque el legajo\n");
        scanf("%d", &y[i]);
    }
}
void arraysEdades(int z[])
{
    for (i = 0; i < 5; i++)
    {
        printf("\nColoque la edad\n");
        scanf("%d", &z[i]);
    }
}

int dameElMaximo(int x[])
{
    int maximo;
    int paso = 0;
    int i;

    for (i = 0; i < 5; i++)
    {
        if(maximo > x[i]|| paso == 0)
        {
            maximo = x[i];

            paso++;
        }
    }
    return maximo;
}

int dameElMinimo(int x[])
{
    int minimo;
    int paso = 0;
    int i;
    if(minimo < x[i] || paso == 0)
    {
        minimo = x[i];

        paso++;
    }
    return minimo;
}

void libreSilla(int x[], int cantidaDeSillas, int laSilla, int valorInicial)
{
    int retorno = 0;

    if(x[laSilla] == valorInicial)
    {
        retorno 1;
    }

    return retorno;
}

void ocuparSilla(int x[], int cantidadDeSillas, int laSilla, int legajo)
{
    int retorno = -1;
    int sillaLibre;

    if(laSilla < cantidadDeSillas)
    {
        sillaLibre = libreSilla( x[],  cantidaDeSillas,  laSilla,  -1)
        if (sillaLibre == 1)
        {
            x[laSilla] = legajo;
        }
    }
    return retorno;
}

 int CalcularEdadLegajoMayor(int legajo[],int edad[])
 {
    int edadMayor;
    int edadMayorLegajo;
    int flag0 = 0;

    //tomar maximo valor desde la funcion e igualo a la variable

    if(flag0 == 0 || edadMayor > edad[i])
    {
        edadMayor = edad[i];
        edadMayorLegajo = legajo[i];
    }

    return edadMayor;
 }

 void MostrarEdadLegajoMaximo(int edadMayor, int edadMayorLegajo)
{
    printf("La edad maxima %d y el legajo del mismo %d", edadMayor, edadMayorLegajo);
}








































/*
void ocuparSilla(int x[], int cantidad deSillas, int laSilla, int legajo)
{
    int retorno = -1;
    int sillaLibre;

    if()
    {
        sillaLibre =
    }

}
*/

/*
void MostrarMaximo(int respuesta1)
{
    printf("El maximo %d", respuesta1);
}

void MostrarMinimo(int respuesta2)
{
    printf("El maximo %d", respuesta1);
}
*/
/*
void CargarArray(int x[],int cantidadDeSillas, int valorInicial)
{
    int i;

    for (i = 0; i < MAX; i++)
    {

    }
}
*/
