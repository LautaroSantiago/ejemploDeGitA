#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"
#define MAX 5

void arrayDeSillas(int x[])
{
    for (i = 0; i < 5; i++)
    {
        printf("\nColoque el numero de la silla\n");
        scanf("%d", &x[i]);
    }
}

int dameElMaximo(int x[])
{
    int maximo;
    int paso = 0;
    int i;

    for (i = 0; i < 5; i++)
    {
        if(maximo > x[i]|| paso == 0)
        {
            maximo = x[i];

            paso++;
        }
    }
    return maximo;
}

int dameElMinimo(int x[])
{
    int minimo;
    int paso = 0;
    int i;
    if(minimo < x[i] || paso == 0)
    {
        minimo = x[i];

        paso++;
    }
    return minimo;
}

void libreSilla(int x[], int cantidaDeSillas, int laSilla, int valorInicial)
{
    int retorno = 0;

    if(x[laSilla] == valorInicial)
    {
        retorno 1;
    }

    return retorno;
}

void ocuparSilla(int x[], int cantidadDeSillas, int laSilla, int legajo)
{
    int retorno = -1;
    int sillaLibre;

    if(laSilla < cantidadDeSillas)
    {
        sillaLibre = libreSilla( x[],  cantidaDeSillas,  laSilla,  -1)
        if (sillaLibre == 1)
        {
            x[laSilla] = legajo;
        }
    }
    return retorno;
}



/*
void ocuparSilla(int x[], int cantidad deSillas, int laSilla, int legajo)
{
    int retorno = -1;
    int sillaLibre;

    if()
    {
        sillaLibre =
    }

}
*/

/*
void MostrarMaximo(int respuesta1)
{
    printf("El maximo %d", respuesta1);
}

void MostrarMinimo(int respuesta2)
{
    printf("El maximo %d", respuesta1);
}
*/
/*
void CargarArray(int x[],int cantidadDeSillas, int valorInicial)
{
    int i;

    for (i = 0; i < MAX; i++)
    {

    }
}
*/
