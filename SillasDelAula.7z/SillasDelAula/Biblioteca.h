
void arrayDeSillas[int x[]);
int dameElMaximo(int x[]);
int dameElMinimo(int x[]);
void libreSilla(int x[], int cantidaDeSillas, int laSilla, int valorInicial)
void ocuparSilla(int x[], int cantidadDeSillas, int laSilla, int legajo)

//void CargarArray();
//void MostrarMaximo(int respuesta1);
//void MostrarMinimo(int respuesta2);

