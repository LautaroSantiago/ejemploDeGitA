#include <stdio.h>
#include <stdlib.h>
#include "Sillas.h"
#define cantidad 5

int main()
{
    int numeroDeSilla[cantidad];
    int maximo;
    int minimo;
    int primeraSilla;
    int sillaLibre;
    int sillaLibreContador = 0;
    int sillaOcupada;
    int sillaOcupadaContador = 0;

    printf("El maximo es %", maximo);
    printf("El minimo es %", minimo);

    CargarSillas(numeroDeSilla[]);
    maximo = MaximoSilla(numeroDeSilla[cantidad]);
    minimo = MinimoSilla(numeroDeSilla[cantidad]);

    return 0;
}

void CargarSillas(int x[])
{
    int i;

    for (i = 0; i < cantidad; i++)
    {
        printf("Coloque la silla: ");
        scanf("%d", &x[i]);
    }
}

int MaximoSilla(int x[], int elMaximo)
{
    int i;
    int flag = 0;
    //int retorno = 1;

    for (i = 0; i < cantidad; i++)
    {
        if(flag == 0 || elMaximo > x[i])
        {
            x[i] = elMaximo;
            flag = 1;
        }
    }
    return elMaximo;
}

int MinimoSilla(int x[], int elMinimo)
{
    int i;
    int flag1 = 0;
    //int retorno = 1;

    for (i  = 0; i < cantidad; i++)
    {
        if (flag1 = 0 || elMinimo > x[i])
        {
            x[i] = elMinimo;
            flag1 = 1;
        }
    }
    return elMinimo;
}

int
