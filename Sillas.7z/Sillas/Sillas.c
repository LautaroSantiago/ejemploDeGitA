#include <stdio.h>
#include <stdlib.h>
#include "Sillas.h"
#define cantidad 5
