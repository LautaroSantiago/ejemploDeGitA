#include "Alumno.h"

int buscarLibre(eAlumno listadoDeAlumnos[], int tam)
{
    int indice = -1;
    int i;

    for(i=0;i<tam;i++)
    {
        if(listadoDeAlumnos[i].estado!=OCUPADO)
        {
            indice = i;
            break;
        }
    }
    return indice;

}


void hardCodearAlumnos(eAlumno listadoDeAlumnos[], int tam)
{
    int i;
    int legajo[]= {101,102,105};
    float promedio[]= {6.66, 4,7.66};
    char nombre[][25]= {"Juan","Maria josefina","Maria"};
    for(i=0; i<3; i++)
    {
        listadoDeAlumnos[i].legajo = legajo[i];
        listadoDeAlumnos[i].promedio = promedio[i];
        strcpy(listadoDeAlumnos[i].nombre, nombre[i]);
        listadoDeAlumnos[i].estado = OCUPADO;

    }


}

void mostrarListadoAlumnos(eAlumno listadoDeAlumnos[], int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        if(listadoDeAlumnos[i].estado==OCUPADO)
        {
            mostrarUnAlumno(listadoDeAlumnos[i]);
        }

    }
}
///validar
void cargarListadoAlumnos(eAlumno listadoDeAlumnos[], int tam)
{
    int i;
    int indice;

    indice = buscarLibre(listadoDeAlumnos, tam);
    printf("Indice: %d\n", indice);
    if(indice!=-1)
    {
        //hay lugar
        listadoDeAlumnos[indice] = cargarAlumno();
    }
    else
    {
        printf("No hay espacio disponible");
    }

}

eAlumno cargarAlumno(void)
{
    eAlumno miAlumno;

    printf("Ingrese legajo: ");
    scanf("%d", &miAlumno.legajo);
    printf("Ingrese nombre: ");
    fflush(stdin);
    scanf("%[^\n]", miAlumno.nombre);
    printf("Ingrese promedio: ");
    scanf("%f", &miAlumno.promedio);

    miAlumno.estado = OCUPADO;

    return miAlumno;
}
void mostrarUnAlumno(eAlumno miAlumno)
{
    printf("%4d %25s %8.2f\n",miAlumno.legajo,miAlumno.nombre, miAlumno.promedio);
}

void sortStudentsByNameAndAverage(eAlumno listadoDeAlumnos[], int tam)
{
    int i;
    int j;
    eAlumno auxAlumno;

    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(strcmp(listadoDeAlumnos[i].nombre,listadoDeAlumnos[j].nombre)>0)
            {
                auxAlumno = listadoDeAlumnos[i];
                listadoDeAlumnos[i] = listadoDeAlumnos[j];
                listadoDeAlumnos[j] = auxAlumno;
            }

            else
            {
                if(strcmp(listadoDeAlumnos[i].nombre,listadoDeAlumnos[j].nombre)==0)
                {
                    if(listadoDeAlumnos[i].promedio>listadoDeAlumnos[j].promedio)
                    {
                        auxAlumno = listadoDeAlumnos[i];
                        listadoDeAlumnos[i] = listadoDeAlumnos[j];
                        listadoDeAlumnos[j] = auxAlumno;
                    }
                }
            }
        }
    }

}

void BuscarAlumno(eAlumno listadoDeAlumnos[], int tam)
{
    int i;
    int flag = 0;
    int LegajoBuscar;

    printf("Coloque el Legajo a buscar");
    scanf("%d", LegajoBuscar);

    for(i = 0; i < tam; i++)
    {
        if((strcmp(listadoDeAlumnos[tam], eAlumno.legajo)==LIBRE)
        {
            LegajoBuscar = mostrarUnAlumno(eAlumno.legajo);
        }
        if(flag == 0)
        {
            printf("No se encontro a nadie");
            flag = 1;
        }

    }
    return NombreBuscar;
}

/*
void buscarUnNombre(eAlumno listadoDeAlumnos[], int tam)
{
    int flagPrimerIndice=1;
    int i;
    char nombreABuscar[256];
    printf("Ingrese el nombre a buscar: ");
    gets(nombreABuscar);
    fflush(stdin);

    for(i=0;i<tam;i++)
    {
        if((strcmp(listadoDeAlumnos[i].nombre,nombreABuscar)==0) && listadoDeAlumnos[i].estado==LIBRE)
        {
            printf("\nSe encontro el nombre: %s\n",listadoDeAlumnos[i].nombre);
            flagPrimerIndice=0;
        }
    }
    if(flagPrimerIndice == 1)
    {
        printf("\nEl nombre a buscar no existe\n");
    }
}
*/
/*
eAlumno OrdenarAlumnos()
{

}
*/
