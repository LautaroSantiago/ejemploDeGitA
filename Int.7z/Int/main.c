#include <stdio.h>
#include <stdlib.h>
#include "Int.h"
#define cantidad 5

int main()
{
    int silla[cantidad];
    int edad[cantidad];
    int legajo[cantidad];
    int maximo;
    int minimo;
    int laEdadMaximo;
    int laEdadMaximoConLegajo;
    int elLegajoMaximo;
    int elLegajoMaximoConEdad;

    IngresoSilla(silla);
    IngresoEdad(edad);
    IngresoLegajo(legajo);

    maximo = SillaMayor(silla);
    MostrarMayor(maximo);

    minimo = SillaMenor(silla);
    MostrarMenor(minimo);

    laEdadMaximo = EdadMayor(edad, legajo);
    MostrarMayorEdad(laEdadMaximo, laEdadMaximoConLegajo);

    elLegajoMaximo = LegajoMayor(legajo, edad);
    MostrarMayorLegajo(elLegajoMaximo, elLegajoMaximoConEdad);

    return 0;
}
