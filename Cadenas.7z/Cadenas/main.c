#include <stdio.h>
#include <stdlib.h>
#include <string.h>///permite mayor uso del string(cadena)
#include <ctype.h>
#define valor 10

///toLowerCase() = tolower(palabra);                                                       MINUSCULA LETA
///toUperCase() = strupr(palabra);                                                         MAYUSCULA STRING

int main()
{

    char palabra[10];///guardaria 9, = al momento de definirlo
    ///o2 char otraPalabra[100];
    ///o2 char otraPalabra[100];
    ///o2.1.1 int comp;
    //int i;
    ///0.2 int i;
    ///final de cadena \0, 1 mas para ese termino
    ///o1 int largo; LARGO

        ///o2 strcpy(vector, palabra entre comillas);/// le asigna a la variable, ese valor COPIA
        ///o2 strcpy(variable, otra variable);       ///                                    COPIA
        ///o2 strcpy(palabra, otraPalabra);          ///                                    COPIA
        ///o2 strcpy(palabra, "hola");                                                      COPIA

    //for(i = 0; i < valor; i++){}
    printf("Ingrese una palabra: \n");
    fflush(stdin);                               /// el espacio se considera \0, no lee el resto
        ///fgets(palabra, 10    , stdin  ); para windows y LINUX, tiene un bug, guarda\n
        ///fgets(palabra, tama�o, archivo);

    gets(palabra);///usar esta funcion, para windows
    ///o0 scanf("%[^\n]", palabra);
    ///No usar el scanf("%s", palabra);         ///no necesita el &, ni el[]                NO USAR
    ///o1 largo = strlen(palabra);              ///devuelve cuenta cantidad de caracteres   CUENTA
        ///o1.1 largo = strlen(palabra);                                                    CUENTA
        ///o1.1 palabra [largo-1];                                                          CUENTA
    ///o1 printf("Largo :%d", largo-1);                                                     CUENTA
        ///o1.1 printf("Largo :%d", largo-1);                                               CUENTA
    ///opcional strupr(palabra);                                                            MAYUSCULA STRING
    ///strlwr(palabra);                                                                     MINUSCULA STRING
    printf("%s", palabra);

    ///o2.1 comp = strcmp(palabra, otraPalabra);                                                                    COMPARA
    ///o2.1 strcmp(palabra, otraPalabra);         ///devuelve otro entero, compara si son iguales                   COMPARA
    ///o2.1.1 stricmp(palabra, otraPalabra);      ///devuelve otro entero, compara si son iguales si tiene el 'i'   COMPARA SIN DISTINGUIR MINUSCULA MAYUSCULA
    ///o3 strcat(palabra, otraPalabra);           ///concatena de a pares, si una variable no tiene valor toma basura, para eso inicializo todo en ''   CONCATENA

    return 0;
    return 0;
}
