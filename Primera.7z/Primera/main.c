#include <stdio.h>
#include <stdlib.h>

int main()
{
    char palabra[10] = "pcOjz";
    char mayus;
    char primeraLetra[1];
    int flag = 0;
    int i = 0;
    char frase[10];



    mayus = toupper (palabra[0]);

    if(palabra[0] && flag == 0)
    {
        strcpy(primeraLetra, palabra);
        toupper(primeraLetra);
        flag = 1;
    }

    frase = printf("%c%s\n", mayus,palabra);
}

void PedirPalabra(char laPalabra);
{
    fflush(stdin);
    gets(palabra);

    strlwr(palabra);
}
