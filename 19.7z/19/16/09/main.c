#include <stdio.h>
#include <stdlib.h>
#define CANTIDAD 5
///define tipos de datos
/** \brief Colocar datos del alumno, si el lugar del alumno esta ocupado avisar (crear variable que permita
 * mostrar todos y no un hacer uno por uno)
 *
 *
 *
 * \return
 */

typedef struct
{
    char nombre[50];
    int nota;
    int legajo;
    int estaVacio;///0 para ocupado 1 para esta vacio

}eAlumno;

void inicializarAlumnos(eAlumno listadoDeAlumnos[], int cantidad)
{

    int listadoDeEnteros[5];
    int tieneAlumno = 0;
    int i;

    for(i = 0; i < cantidad ; i++)
    {
        printf("PEDIR LISTADO\n");
        scanf("%d", &listadoDeAlumnos[i].estaVacio);

        if(listadoDeAlumnos[i].estaVacio == 1)
        {
            printf("Esta vacio");
        }
        else
        {
            listadoDeAlumnos[i].estaVacio = 0;
            printf("Esta ocupado");
        }
    }

}




/*
void listarAlumnos(eAlumno listadoDeAlumnos[], int cantidad)
{
    eAlumno listadoDeAlumnos[5];
    int i;
    int flag = 0;


    for(i = 0; i < 5 ; i++)
    {
        if(listadoDeAlumnos[i].estaVacio == 1)
        {
            printf("Esta vacio");
        }
        else
        {
            listadoDeAlumnos[5].estaVacio = 0;
            printf("Esta ocupado");
        }
    }
}
*/
///VER
void MostarAlumnos(eAlumno listado[], int )
{

    int i;
    int tieneAlumnos = 0;

    for(i = 0; i < 5 ; i++)
    {
        if(listado[i].estaVacio == 0)
        {
            tieneAlumnos = 0;
            ///llamadada Mostrar un alumno(listado[])
        }
        if(listado[i].estaVacio == 1)
        {
            printf("No hay alumnos para mostrar");
        }
    }


}

void MostarUnAlumno(eAlumno Alguno)
{
    printf("%d", Alguno);
}

int main()
{
    int opcion;
    eAlumno ArrayDeAlumno[TAMANIO];
    eAlumno NuevoAlumno;
    int listadoDeEnteros[5];
    int numero;
    eAlumno listadoDeAlumnos[5];
    eAlumno UnAlumno;
    eAlumno OtroAlumno;
    int i;
    int indice;
///
    int legajoaux = {1,3,5,9,88};
    char nombreaux [][50] = {"Juan","Pedro","Maria","Julieta","Pepe"};
    int notaaux = {10,2,9,4,6};

indice = DameElIndice(ArrayDeAlumnoa , TAMANIO)
if(indice != 1)
{
    ArrayDeAlumno[indice] = NuevoAlumno;
    MostarUnAlumno(listado[i]);
}
else
{
    printf("No hay lugares libres");
}

    //llamadas
    ArraysDeAlumnos[2] = NuevoAlumno;
/*
    for(i = 0; i < 5 ; i++)
    {
        printf("PEDIR LISTADO\n");
        scanf("%d", &listadoDeAlumnos[i].estaVacio);

        if(listadoDeAlumnos[i].estaVacio == 1)
        {
            printf("Esta vacio");
        }
        else
        {
            listadoDeAlumnos[5].estaVacio = 0;
            printf("Esta ocupado");
        }
    }
*/
///hacer menu
do
{
    system("cls");
    printf("\nCargar \n");
    printf("\nMostrar \n");
    printf("\nBuscar \n");
    printf("\nBorrar \n");
    scanf("%d", opcion);

    switch(opcion)
    {
        case 1:
            printf("\nCargar \n");

            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
    }
    system("pause");
}
while(seguir == 's');

///HARCODEDO
/*
    printf("PEDIR NUMERO\n");
    scanf("%d", &numero);
    printf("NUMERO %d\n", numero);

    printf("PEDIR NOTA\n");
    scanf("%d", &UnAlumno.nota);
    printf("NOTA %d\n", UnAlumno.nota);

    printf("PEDIR NOMBRE\n");
    scanf("%s", &UnAlumno.nombre);
    printf("NOMBRE %s\n", UnAlumno.nombre);

    ///OTRO ALUMNO
    printf("PEDIR NOTA\n");
    scanf("%d", &OtroAlumno.nota);
    printf("NOTA %d\n", OtroAlumno.nota);

    printf("PEDIR NOMBRE\n");
    scanf("%s", &OtroAlumno.nombre);
    printf("NOMBRE %s\n", OtroAlumno.nombre);
*/
   return 0;
}

int IndiceVacio(eAlumno listado, TAMANIO)
{
    int i;
    int elIndiceVacio = 1;

    if(elIndiceVacio == 1)
    {

        elIndiceVacio = 0;
        return ;
    }
    return ;
}

int AlumnoDatos(eAlumno EsVacio ,eAlumno Esnombre ,eAlumno Esnota , eAlumno Eslegajo,TAMANIO)
{
    EsVacio.estaVacio;
    Esnombre.nombre;
    Esnota.nota;
    Eslegajo.legajo;
}

void MostarAlumnos()
{
    int aviso = 0;

    if(aviso == 0)
    {

        aviso = 1;
    }

}

/*

int buscarAlumnoNombre(eAlumno ElNombre[], TAMANIO)
{
    char NombreResivido[50];
    int igual;
///hacer llamada
    igual = strcmp(NombreResivido, ElNombre);

    if(igual == 0)
    {
        printf("El nombre existe");
    }
    else
    {
        printf("El nombre no existe");
        scanf("s", &ElNombre[i])
    }
}
int borrarAlumnoLegajo(eAlumno ElLegajo, TAMANIO)
{
    int LegajoResivido;

}
*/

